<?php
namespace Braintree\Exception;

use Braintree\Exception;

class InvalidChallenge extends Exception
{
}
